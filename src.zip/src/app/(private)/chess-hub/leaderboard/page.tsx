import { FC } from "react";
import React from "react";
import { ClassLeaderboard } from "@/page/student-components/student-leaderboard";

const LeaderboardPage= () => {
  return <div></div>;
};

export default LeaderboardPage;
