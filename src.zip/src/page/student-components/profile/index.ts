import { GameInfo } from './GameInfo';
export {default as ProfileCard} from './ProfileCard';
export {default as QuickStats} from './QuickStats';     
export {default as SkillAnalysis} from './SkillAnalysis';
export {default as Recommendations} from './Recommendations';
export {default as GameInfo} from './GameInfo';