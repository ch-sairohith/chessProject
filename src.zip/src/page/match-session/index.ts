export {default as MatchSettingsCard } from './matchSettingsCard';
export { default as GradesCard } from "./GradesCard";
export {default as MatchPairingCard} from "./MatchPairingCard";
